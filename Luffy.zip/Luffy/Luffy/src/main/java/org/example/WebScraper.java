package org.example;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class WebScraper {

    static WebDriver driver;

    public static void main(String[] args) {
        try {
            String gameName = "Hollow Knight";
            String url = "https://freegogpcgames.com/2034/1-hollow-knight/";

            // Configurazione del WebDriver
            setupDriver();

            String downloadLink = getDownloadLink(url);
            if (downloadLink != null) {
                System.out.println("First Download Link: " + downloadLink);
                String magnetLink = getMagnetLink(downloadLink);
                if (magnetLink != null) {
                    System.out.println("Magnet Link: " + magnetLink);
                } else {
                    System.out.println("Magnet link not found.");
                }
            } else {
                System.out.println("Download link not found.");
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (driver != null) {
                driver.quit();
            }
        }
    }

    // Funzione per configurare il WebDriver con WebDriverManager
    public static void setupDriver() {
        WebDriverManager.chromedriver().setup(); // Gestisce automaticamente il driver
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--headless");  // Esegui in modalità headless
        driver = new ChromeDriver(options);
    }

    // Funzione per ottenere il primo link di download
    public static String getDownloadLink(String url) {
        try {
            driver.get(url);

            // Attendere che il link di download sia visibile (fino a 10 secondi)
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
            WebElement downloadBtn = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".download-btn")));

            // Restituire l'href del primo link di download
            return downloadBtn.getAttribute("href");
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    // Funzione per ottenere il link magnet
    public static String getMagnetLink(String url) throws InterruptedException {
        try {
            driver.get(url);

            // Attendere che il link magnet sia visibile (fino a 10 secondi)
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
            WebElement magnetLinkElement = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("a[href^=magnet:]")));

            // Restituire il link magnet
            return magnetLinkElement.getAttribute("href");
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
