package org.example;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class WebScraper {
    public static void main(String[] args) {
        // URL della pagina da cui fare scraping
        String url = "https://dodi-repacks.site/";

        try {
            // Crea un oggetto URL
            URL urlObj = new URL(url);
            HttpURLConnection connection = (HttpURLConnection) urlObj.openConnection();

            // Imposta il metodo di richiesta
            connection.setRequestMethod("GET");

            // Aggiungi header personalizzati per simulare un vero browser
            connection.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36");
            connection.setRequestProperty("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7");
            connection.setRequestProperty("Accept-Language", "en-US;q=0.7,en;q=0.3");
            connection.setRequestProperty("Referer", "https://dodi-repacks.site/?__cf_chl_tk=M9AR3lp3mqHt_f0MC_j45mBZoOPg42gT1QO4CAn77JE-1735738964-1.0.1.1-7mHhZq8d.k2s7fS1ily5JhYG_SjoSZZ7Fobm7V6Guqo");

            //cookie da aggiornare giornalmente
            connection.setRequestProperty("Cookie", "cf_clearance=CfUIqS4cy.vyfhlRsvAVEQVRYj5aM8fexdL3DyvUsts-1736170924-1.2.1.1-OBDrsLZVslGhDVJraaNH_HzW1.jCZIQha_8nj8H9qAeDj2V5Z97hwH6Boxd_SbK5mAAlXbs6K8iZRNKjuxi5IPPKBFu02OdbZnRubccOqOMctcUtLMaaE47uGcnXMBO9p88p90NpKZ.e6Tr8KXudv96Rlned2yNm12EAgrggtJobGFcCwegklO1W2SITSAwwit_9d4fZivN81aZwI9vHUGHk9Bxpls1ssGKTfUCtXUJRhVTbXWjCHLoqU16b9h8NTY_THkjlMniLlqS5LtZRkq5jxzvSN23jG8U9pB2wf02l21bxkXYxEPkoVuJLqFXMtr4Nkw8uAnsLKCmmbi5YD.mmogIDfErMctjfRYKj5OwjE7gDuWTtFZqD7GA25XZe9eaVBAu4_VNGVNmkJqp7jiQkFNTur0Uf5CIKA5rZNBOjE_n0eGEFKb2BxSH_dxbq");
            connection.setRequestProperty("sec-ch-ua", "\"Google Chrome\";v=\"131\", \"Chromium\";v=\"131\", \"Not_A Brand\";v=\"24\"");
            connection.setRequestProperty("sec-ch-ua-arch", "\"x86\"");
            connection.setRequestProperty("sec-ch-ua-bitness", "\"64\"");
            connection.setRequestProperty("sec-ch-ua-full-version", "\"131.0.6778.205\"");
            connection.setRequestProperty("sec-fetch-dest", "document");
            connection.setRequestProperty("sec-fetch-mode", "navigate");
            connection.setRequestProperty("sec-fetch-site", "same-origin");
            connection.setRequestProperty("sec-fetch-user", "?1");
            connection.setRequestProperty("Upgrade-Insecure-Requests", "1");
            connection.setConnectTimeout(5000);
            connection.setReadTimeout(5000);


            // Timeout per connessione e lettura
            connection.setConnectTimeout(50000);  // 5 secondi di timeout per la connessione
            connection.setReadTimeout(50000);     // 5 secondi di timeout per la lettura della risposta

            // Ottieni la risposta
            int responseCode = connection.getResponseCode();
            if (responseCode == HttpURLConnection.HTTP_OK) {
                // Leggi il contenuto della risposta
                BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                String inputLine;
                StringBuilder content = new StringBuilder();

                while ((inputLine = in.readLine()) != null) {
                    content.append(inputLine);
                }
                in.close();

                // Usa jsoup per analizzare il contenuto HTML
                Document doc = Jsoup.parse(content.toString());

                // Estrai il titolo della pagina
                String title = doc.title();
                System.out.println("Titolo della pagina: " + title);

                // Estrai tutti i link
                doc.select("a").forEach(element -> {
                    System.out.println("Link trovato: " + element.attr("href"));
                });
            } else {
                System.out.println("Errore nella richiesta, codice di risposta: " + responseCode);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
